

'use client'

import Services from '../reuseable/Services';
const GraphicDesign = () => {

  return (
    <>
      <Services />
    </>
  );
};

export default GraphicDesign
