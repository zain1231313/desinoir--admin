'use client';

import Services from "../reuseable/Services";

const Uidesign = () => {

    return (
        <>
            <Services  />
        </>
    );
};

export default Uidesign;
