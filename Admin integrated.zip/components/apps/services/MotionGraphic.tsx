

'use client'
import Services from '../reuseable/Services';
const MotionGraphic = () => {

    return (
        <>
            <Services />
        </>
    );
};
export default MotionGraphic;
