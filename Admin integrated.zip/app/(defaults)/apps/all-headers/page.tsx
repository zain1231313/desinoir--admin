import AllHeader from '@/components/apps/allheaders/AllHeader'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';

import React from 'react'

const page = () => {
    return (
        <>
            <AllHeader />
        </>
    )
}

export default page
