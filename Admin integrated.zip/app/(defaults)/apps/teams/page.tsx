import Teams from '@/components/apps/team/Teams'
import React from 'react'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
function page() {
  return (
    <>
      <Teams/>
    </>
  )
}

export default page
