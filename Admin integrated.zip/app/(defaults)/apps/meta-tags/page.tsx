import MetaTags from '@/components/apps/meta-tags/MetaTags'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react'

const page = () => {
    return (
        <>
            <MetaTags />
        </>
    )
}

export default page
