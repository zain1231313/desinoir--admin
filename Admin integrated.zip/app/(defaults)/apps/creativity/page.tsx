import React from 'react'
import Creativity from '../../../../components/apps/creativity/Creativity'

const page = () => {
    return (
        <>
            <Creativity />
        </>
    )
}

export default page
