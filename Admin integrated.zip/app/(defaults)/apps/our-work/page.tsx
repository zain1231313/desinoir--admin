import OurWork from '@/components/apps/our-work/OurWork'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';

import React from 'react'

function page() {
  return (
    <div>
      <OurWork />
    </div>
  )
}

export default page
