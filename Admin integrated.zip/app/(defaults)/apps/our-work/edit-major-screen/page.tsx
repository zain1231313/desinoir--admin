import EditMajorScreen from '@/components/apps/our-work/EditMajorScreen';
import React from 'react';

function page() {
    return (
        <div>
            <EditMajorScreen />
        </div>
    );
}

export default page;
