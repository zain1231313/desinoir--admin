import AddWorks from '@/components/apps/our-work/AddWorks'
import React from 'react'

const page = () => {
    return (
        <>
            <AddWorks />
        </>
    )
}

export default page
