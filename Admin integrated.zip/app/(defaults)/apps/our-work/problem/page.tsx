import ProblemTable from '@/components/apps/our-work/ProblemTable'
import React from 'react'

function page() {
  return (
    <div><ProblemTable/></div>
  )
}

export default page