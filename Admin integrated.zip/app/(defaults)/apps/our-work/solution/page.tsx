import SolutionTable from '@/components/apps/our-work/SolutionTable';
import React from 'react';

function page() {
    return (
        <div>
            <SolutionTable />
        </div>
    );
}

export default page;
