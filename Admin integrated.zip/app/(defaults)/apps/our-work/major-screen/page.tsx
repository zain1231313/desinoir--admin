import MajorTable from '@/components/apps/our-work/MajorTable';
import React from 'react';

function page() {
    return (
        <div>
            <MajorTable />
        </div>
    );
}

export default page;
