import EditProblemForm from '@/components/apps/our-work/EditProblem';
import React from 'react';

function page() {
    return (
        <div>
            <EditProblemForm />
        </div>
    );
}

export default page;
