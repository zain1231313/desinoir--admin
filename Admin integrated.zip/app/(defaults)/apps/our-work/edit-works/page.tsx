import EditWork from "@/components/apps/our-work/EditWork"

const page = () => {
    return (
        <>
            <EditWork />
        </>
    )
}

export default page
