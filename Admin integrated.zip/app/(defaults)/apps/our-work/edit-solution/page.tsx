import EditSolution from '@/components/apps/our-work/EditSolution';
import React from 'react';

function page() {
    return (
        <div>
            <EditSolution />
        </div>
    );
}

export default page;
