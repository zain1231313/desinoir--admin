import ChallengeTable from '@/components/apps/our-work/ChallengesTable';
import React from 'react';

function page() {
    return (
        <div>
            <ChallengeTable />
        </div>
    );
}

export default page;
