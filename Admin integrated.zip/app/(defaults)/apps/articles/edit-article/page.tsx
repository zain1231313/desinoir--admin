import EditArticle from '@/components/apps/articles/EditArticle'
import React from 'react'

const page = () => {
    return (
        <>
            <EditArticle />
        </>
    )
}

export default page
