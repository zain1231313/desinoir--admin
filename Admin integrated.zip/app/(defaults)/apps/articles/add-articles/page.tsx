import AddArticle from '@/components/apps/articles/AddArticle'
import React from 'react'

const page = () => {
    return (
        <>
            <AddArticle />
        </>
    )
}

export default page
