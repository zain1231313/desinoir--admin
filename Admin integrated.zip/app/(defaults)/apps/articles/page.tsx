import Articles from '@/components/apps/articles/Articles';
import React from 'react';
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
function page() {
    return (
        <>
            <Articles />
        </>
    );
}

export default page;
