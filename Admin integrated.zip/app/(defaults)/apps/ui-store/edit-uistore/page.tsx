import React from 'react'
import UpdateUiStore from '../../../../../components/apps/uistore/UpdateUiStore'

const page = () => {
    return (
        <>
            <UpdateUiStore />
        </>
    )
}

export default page
