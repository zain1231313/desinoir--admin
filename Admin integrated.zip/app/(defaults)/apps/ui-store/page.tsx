import UiStore from '@/components/apps/uistore/UiStore'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';

import React from 'react'

const page = () => {
  return (
    <>
     <UiStore/> 
    </>
  )
}

export default page
