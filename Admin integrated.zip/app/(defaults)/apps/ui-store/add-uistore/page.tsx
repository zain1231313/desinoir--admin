import AddUiStore from '@/components/apps/uistore/AddUiStore'
import React from 'react'

const page = () => {
    return (
        <>
            <AddUiStore />
        </>
    )
}

export default page
