import Slider from '@/components/apps/slider/Slider'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react'

const page = () => {
    return (
        <div>
            <Slider />
        </div>
    )
}

export default page
