import React from 'react'
import MainServices from '../../../../components/apps/main-services/MainServices'

const page = () => {
    return (
        <>
            <MainServices />
        </>
    )
}

export default page
