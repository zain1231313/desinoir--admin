import React from 'react'
import HomeHeader from '../../../../components/apps/homeHeader/HomeHeader'

const page = () => {
    return (
        <>
            <HomeHeader />
        </>
    )
}

export default page
