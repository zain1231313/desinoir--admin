import Testimonial from '@/components/apps/testimonial/Testimonial'
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react'

function page() {
  return (
    <>
      <Testimonial />
    </>
  )
}

export default page
