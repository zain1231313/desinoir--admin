import ComponentsDashboardSales from '@/components/dashboard/components-dashboard-sales'
import React from 'react'

const page = () => {
    return (
        <div>
            <ComponentsDashboardSales />
        </div>
    )
}

export default page
