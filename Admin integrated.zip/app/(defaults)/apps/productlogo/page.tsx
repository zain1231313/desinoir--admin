import ProductLogo from '@/components/apps/productlogo/ProductLogo';
import '../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react';

function page() {
    return (
        <div>
            <ProductLogo />
        </div>
    );
}

export default page;
