import AboutCreative from '@/components/apps/about/AboutCreative';
import React from 'react';

function page() {
    return (
        <div>
            <AboutCreative />
        </div>
    );
}

export default page;
