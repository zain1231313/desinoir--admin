import AboutWhyChoose from '@/components/apps/about/WhyDesignoir ';
import React from 'react';

function page() {
    return (
        <div>
            <AboutWhyChoose />
        </div>
    );
}

export default page;
