import AboutProject from '@/components/apps/about/ProjectComplete';
import React from 'react';

function page() {
    return (
        <div>
            <AboutProject />
        </div>
    );
}

export default page;
