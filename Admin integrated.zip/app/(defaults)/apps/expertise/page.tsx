import Expertise from '@/components/apps/expertise/Expertise'
import React from 'react'

const page = () => {
    return (
        <div>
            <Expertise />
        </div>
    )
}

export default page
