
import Footer from '@/components/apps/footer/Footer'
import React from 'react'

const page = () => {
    return (
        <>
            <Footer />
        </>
    )
}

export default page

