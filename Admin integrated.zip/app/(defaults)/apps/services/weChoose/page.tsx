import React from 'react';
import OurChoose from './OurChoose';
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';

function page() {
    return (
        <div>
            <OurChoose />
        </div>
    );
}

export default page;
