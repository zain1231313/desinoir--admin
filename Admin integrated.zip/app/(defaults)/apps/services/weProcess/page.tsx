import MainProcess from '@/components/apps/reuseable/MainProcess';
import ProcessData from '@/components/apps/reuseable/ProcessData';
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react';
import OurProcess from './OurProcess';

function page() {
    return (
        <div>
            <OurProcess />
        </div>
    );
}

export default page;
