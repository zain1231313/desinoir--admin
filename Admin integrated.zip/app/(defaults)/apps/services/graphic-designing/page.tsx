import GraphicDesign from '@/components/apps/services/GraphicDesign'
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react'

function page() {
  return (
    <div>
      <GraphicDesign/>
    </div>
  )
}

export default page
