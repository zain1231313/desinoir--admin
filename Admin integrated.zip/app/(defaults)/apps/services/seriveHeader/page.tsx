import MainService from '@/components/apps/reuseable/MainService';
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react';

function page() {
    return (
        <div>
            <MainService  />
        </div>
    );
}

export default page;
