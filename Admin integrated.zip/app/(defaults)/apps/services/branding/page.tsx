import Branding from '@/components/apps/services/Branding';
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react';

function page() {
    return (
        <div>
            <Branding />
        </div>
    );
}

export default page;
