import MainWeWork from '@/components/apps/reuseable/MainWeWork';
import Workdata from '@/components/apps/reuseable/Workdata';
import '../../../../../node_modules/datatables.net-dt/css/dataTables.dataTables.min.css';
import React from 'react';
import OurWok from './OurWok';

function page() {
    return (
        <div>
            <OurWok />
        </div>
    );
}

export default page;
